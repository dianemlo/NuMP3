const express = require('express')
const router = express.Router()
const { updateProfilePicture } = require('../controllers/userController')
const { protect } = require('../middleware/authMiddleware')

router.put('/profile-picture', protect, updateProfilePicture)

module.exports = router
